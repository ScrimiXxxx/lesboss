
import discord
from discord.ext import commands

import discord
from discord import client

default_intents = discord.Intents.default()
default_intents.members = True
Client = discord.Client(intents=default_intents)

PREFIX = ("+")
bot = commands.Bot(command_prefix=PREFIX, description='Hi')


@bot.event
async def on_ready():
    print("le bot est prêt")


@bot.event
async def on_ready():
    activity = discord.Game(name="uno", type=3)
    await bot.change_presence(status=discord.Status.online, activity=activity)
    print("le bot est prêt")


@bot.command()
async def ban(ctx, user : discord.User, *, reason = "Aucune raison"):
    reason = " ".join(reason)
    #await ctx.guild.ban(user, reason=reason)
    embed = discord.Embed(title = "** Banissement**", description="Un modérateur a frappé", url='https://youtu.be/dQw4w9WgXcQ', color=0x33FFC6)
    embed.set_author(name=ctx.author.name, icon_url=ctx.author.avatar_url)
    embed.set_thumbnail(url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2eh5TO_vAyPuEtl0IY0LeyrlxmoQnMinv3g&usqp=CAU')
    embed.add_field(name='Membre banni', value = user.name, inline=False)
    embed.add_field(name ='Raison', value=reason, inline=False)
    embed.add_field(name= 'Modérateur', value = ctx.author.name, inline=True)
    await ctx.send(embed = embed)

bot.run("ODk0MTMxNzA0ODcxMTQ5NTY5.YVljCg.nq4WHpo1TQmREwuAdP2Qw7LZAuw")


@bot.command()
async def kick(ctx, user : discord.User, *reason):
    reason = " ".join(reason)
    await ctx.guild.kick(user, reason=reason)
    embed = discord.Embed(title="**Kick**", description="Un modérateur a frappé")
    await ctx.send(embed=embed)

bot.run("ODk0MTMxNzA0ODcxMTQ5NTY5.YVljCg.nq4WHpo1TQmREwuAdP2Qw7LZAuw")


@bot.command()
async def clear(ctx, nombre : int):
    message = await ctx.channel.history(limit = nombre).flatten()
    for message in messages :
        await message.delete()

bot.run("ODk0MTMxNzA0ODcxMTQ5NTY5.YVljCg.nq4WHpo1TQmREwuAdP2Qw7LZAuw")

